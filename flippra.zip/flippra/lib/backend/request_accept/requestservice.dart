import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class RequestService extends GetxController {
  final isLoading = false.obs;
  final message = ''.obs;

  Future<bool> registerService({
    required String token,
    required String firstname,
    required String lastname,
    required String email,
    required String phoneNumber,
    required String images,
    required String service,
  }) async {
    final url = Uri.parse(
        'https://flippraa.anklegaming.live/APIs/APIs.asmx/AddRequests');

    try {
      isLoading.value = true;

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {
          'token': token,
          'FirstName': firstname,
          'LastName': lastname,
          'Email': email,
          'PhoneNumber': phoneNumber,
          'Images': images,
          'Service': service,
        },
      );

      isLoading.value = false;

      if (response.statusCode == 200) {
        print("✅ Successfully Requested");
        print("🔹 Raw Response: ${response.body}");

        try {
          final Map<String, dynamic> data = jsonDecode(response.body);

          if (data.containsKey("Message")) {
            if (data["Message"].toString().toLowerCase() == "inserted") {
              message.value = "Request inserted successfully ✅";
              return true;
            } else {
              message.value = data["Message"];
              return false;
            }
          } else {
            message.value = "Unexpected response format";
            return false;
          }
        } catch (e) {
          print("⚠️ JSON Parse Error: $e");
          message.value = "Invalid response format";
          return false;
        }
      } else {
        print("❌ Failed with status: ${response.statusCode}");
        message.value = "Failed: ${response.statusCode}";
        return false;
      }
    } catch (e) {
      isLoading.value = false;
      print('❌ Exception while sending request: $e');
      message.value = "Exception: $e";
      return false;
    }
  }
}
