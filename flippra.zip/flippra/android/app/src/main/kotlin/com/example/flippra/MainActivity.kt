package com.example.flippra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
